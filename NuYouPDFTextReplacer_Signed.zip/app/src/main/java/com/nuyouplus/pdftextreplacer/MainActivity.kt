package com.nuyouplus.pdftextreplacer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream

class MainActivity: AppCompatActivity() {
    private lateinit var btnSelect: Button
    private lateinit var btnPreview: Button
    private lateinit var btnReplace: Button
    private lateinit var etFind: EditText
    private lateinit var etReplace: EditText
    private lateinit var tvStatus: TextView
    private var pdfUri: Uri? = null
    private val PICK_PDF = 3001
    private val CREATE_PDF = 3002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        PDFBoxResourceLoader.init(applicationContext)
        btnSelect = findViewById(R.id.btnSelect)
        btnPreview = findViewById(R.id.btnPreview)
        btnReplace = findViewById(R.id.btnReplace)
        etFind = findViewById(R.id.etFind)
        etReplace = findViewById(R.id.etReplace)
        tvStatus = findViewById(R.id.tvStatus)
        btnSelect.setOnClickListener { pickPdf() }
        btnPreview.setOnClickListener { preview() }
        btnReplace.setOnClickListener { saveAs() }
    }

    private fun pickPdf() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
        }
        startActivityForResult(i, PICK_PDF)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        when (requestCode) {
            PICK_PDF -> { pdfUri = data.data; tvStatus.text = "Selected: $pdfUri" }
            CREATE_PDF -> { performReplace(data.data!!) }
        }
    }

    private fun preview() {
        val uri = pdfUri ?: return
        val findText = etFind.text.toString()
        if (findText.isEmpty()) { tvStatus.text = "Enter Find text"; return }
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        var count = 0
        contentResolver.openInputStream(uri).use { input ->
            val doc = PDDocument.load(input)
            val renderer = PDFRenderer(doc)
            for (i in 0 until doc.numberOfPages) {
                val bmp = renderer.renderImage(i, 2.0f)
                val img = InputImage.fromBitmap(bmp, 0)
                val task = rec.process(img)
                val res = Tasks.await(task)
                res.textBlocks.forEach { b -> b.lines.forEach { l ->
                    if (l.text.contains(findText, ignoreCase = true)) count++
                }}
            }
            doc.close()
        }
        tvStatus.text = "Preview: $count matches"
    }

    private fun saveAs() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "NuYouPlus_Rebranded.pdf")
        }
        startActivityForResult(i, CREATE_PDF)
    }

    private fun performReplace(outUri: Uri) {
        val uri = pdfUri ?: return
        val findText = etFind.text.toString()
        val replaceText = etReplace.text.toString()
        if (findText.isEmpty() || replaceText.isEmpty()) { tvStatus.text = "Enter Find and Replace"; return }
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        contentResolver.openInputStream(uri).use { input ->
            val doc = PDDocument.load(input)
            val renderer = PDFRenderer(doc)
            for (i in 0 until doc.numberOfPages) {
                val page = doc.getPage(i)
                val bmp = renderer.renderImage(i, 3.0f)
                val img = InputImage.fromBitmap(bmp, 0)
                val task = rec.process(img)
                val res = Tasks.await(task)
                res.textBlocks.forEach { b -> b.lines.forEach { l ->
                    val box = l.boundingBox
                    if (box != null && l.text.contains(findText, ignoreCase = true)) {
                        val scale = 72f / 216f
                        val x = box.left * scale
                        val w = box.width() * scale
                        val h = box.height() * scale
                        val yTopImage = (bmp.height - box.top) * scale
                        val y = page.mediaBox.upperRightY - yTopImage
                        val cs = PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true)
                        cs.setNonStrokingColor(Color.WHITE)
                        cs.addRect(x, y - h, w, h); cs.fill()
                        cs.beginText()
                        cs.setNonStrokingColor(Color.BLACK)
                        cs.setFont(PDType1Font.HELVETICA_BOLD, maxOf(8f, h*0.6f))
                        cs.newLineAtOffset(x, y - h*0.8f)
                        cs.showText(l.text.replace(findText, replaceText, ignoreCase = true))
                        cs.endText()
                        cs.close()
                    }
                }}
            }
            contentResolver.openOutputStream(outUri).use { out -> doc.save(out) }
            doc.close()
        }
        tvStatus.text = "Saved to: $outUri"
    }
}
