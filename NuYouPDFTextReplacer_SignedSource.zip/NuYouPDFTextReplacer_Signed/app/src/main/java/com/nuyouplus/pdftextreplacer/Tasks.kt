package com.nuyouplus.pdftextreplacer

import com.google.android.gms.tasks.Task
import java.util.concurrent.CountDownLatch

object Tasks {
    fun <T> await(task: Task<T>): T {
        val latch = CountDownLatch(1)
        var res: T? = null
        var err: Exception? = null
        task.addOnSuccessListener { r -> res = r; latch.countDown() }
        task.addOnFailureListener { e -> err = e; latch.countDown() }
        latch.await()
        if (err != null) throw err as Exception
        return res as T
    }
}
